/*
 * Copyright 2018-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * You may not use this file except in compliance with the terms and conditions set forth in the
 * accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
 * DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
 */

/*
    This application is one part of a larger test used by device makers to validate that the HMCU has been
    correctly connected to the ACK Connectivity Module. The larger test expects to see evidence that
    the HMCU initialized and was able to successfully issue a command to the ACK Connectivity Module.
    This application provides that evidence by watching for a module-booted event and then issuing a
    get-status command via ACK_GetStatus.
*/

#include "ack.h"
#include "ack_user_device.h"

// Not used, but must be present to avoid a link error.
ACKPropertyTableEntry_t ACKUser_PropertyTable[] = { 0, NULL };

// Called once, for one-time initialization.
void setup()
{
    // Initialize ACK Host MCU Implementation Core.
    ACK_Initialize();
}

// Called over and over, for main processing.
void loop()
{
    static bool firstPass = true;
    static uint32_t lastTick = 0;
    uint32_t ticks;
    ACKStatus_t status;

    ticks = ACKPlatform_TickCount();
    if (firstPass || ((ticks - lastTick) >= 500))   // throttle to ~2 per second
    {
        lastTick = ticks;
        firstPass = false;

        ACK_GetStatus(&status);

        // 'Unknown' connectivity state means that ACK_GetStatus was unable to communicate with
        // the ACK Connectivity Module. Any other state means that the get-status command was
        // successfully issued to the ACK Connectivity Module, and a reply received. The latter is
        // what this test is looking for.
        if (ACK_CONNECTIVITY_UNKNOWN == status.ConnectivityState)
        {
            ACK_DEBUG_PRINT_I(
                "Waiting for communications to be established with ACK Connectivity Module.");
        }
        else
        {
            // We don't expect the time in the ACKStatus_t struct to be valid at this point,
            // so just print this generic message indicating success.
            ACK_DEBUG_PRINT_I("SUCCESS: communications established with ACK Connectivity Module!");
        }
    }

    ACK_Process();
}

// State-report callback. This sample application does not handle any Alexa capabilities, and so
// this routine is a no-op.
void ACKUser_OnReportStateDirective(int32_t correlationId)
{
}

// Unused, but must be present to avoid link error.
bool ACKUser_IsDeviceInUse(void)
{
    return false;
}
