/*
 * Copyright 2018-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * You may not use this file except in compliance with the terms and conditions set forth in the
 * accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
 * DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
 */

#include "acp.pb.h"
#include "ack_core_common.h"
#include "ack_core_heaplet.h"
#include "ack_core_hostconfig.h"
#include "ack_user_config.h"

ACKError_t HostConfigWrite(uint64_t firmwareVersion)
{
    acp_cmd* pCmd;
    ACKError_t retval;

    ACK_DEBUG_PRINT_I("Sending write host config command");

    pCmd = (acp_cmd*)HeapletSetSize(MEM_OUTBOUND_ACP_CMD, sizeof(*pCmd));
    if (NULL == pCmd)
    {
        retval = ACK_ERR_OUT_OF_MEMORY;
        goto cleanup0;
    }

    pCmd->which_type = acp_cmd_write_host_config_obj_tag;
    pCmd->type.write_host_config_obj.firmware_version = firmwareVersion;
    pCmd->type.write_host_config_obj.host_info_count = 0;

    retval = CommonSendAcpCmdAndGetResponse();

    if (ACK_NO_ERROR != retval)
    {
        ACK_DEBUG_PRINT_E("Error encoding and sending command, err %u", retval);
        goto cleanup0;
    }

    if (!CommonCheckGenericResponse())
    {
        retval = ACK_ERR_PROTOCOL;
        goto cleanup0;
    }

    retval = ACK_NO_ERROR;

cleanup0:
    HeapletFree(MEM_OUTBOUND_ACP_CMD);
    CommonFreeAcpResponse();
    return retval;
}
