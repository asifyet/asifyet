/*
 * Copyright 2018-2019 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * 
 * You may not use this file except in compliance with the terms and conditions set forth in the
 * accompanying LICENSE.TXT file. THESE MATERIALS ARE PROVIDED ON AN "AS IS" BASIS. AMAZON SPECIFICALLY
 * DISCLAIMS, WITH RESPECT TO THESE MATERIALS, ALL WARRANTIES, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
 */

#include "ack_stm32_ota.h"
#include "stm32f0xx_hal.h"

void ACKStm32Ota_FlashBegin(void)
{
    // An error return code indicates that flash is already unlocked.
    // Ignore that.
    HAL_FLASH_Unlock();
}

void ACKStm32Ota_FlashEnd(void)
{
    HAL_FLASH_Lock();
}

bool ACKStm32Ota_FlashErase(uint32_t startPageOrdinal, uint32_t sizeBytes)
{
    // Erase the given range.
    FLASH_EraseInitTypeDef erase = {0};
    erase.TypeErase = FLASH_TYPEERASE_PAGES;
    erase.PageAddress = FLASH_BASE + (startPageOrdinal * FLASH_PAGE_SIZE);
    erase.NbPages = ((sizeBytes + FLASH_PAGE_SIZE) - 1) / FLASH_PAGE_SIZE;
    
    uint32_t errorAddress;
    return HAL_OK == HAL_FLASHEx_Erase(&erase, &errorAddress);
}

bool ACKStm32Ota_FlashWrite(uintptr_t address, const void* pData, uint32_t dataSize16BitValues)
{
    // Odd addresses or no data to program is an error condition.
    if ((address & 1) || ((uintptr_t)pData & 1) || (0 == dataSize16BitValues))
    {
        return false;
    }
    
    // Calling HAL_FLASH_Program is most efficient with 64-bit values. The largest data access
    // on a Cortex-M0 is 32-bit, and memory accesses must be aligned. Assuming pData doesn't have
    // its low bit set (which should never happen, since we check for that above), pData can
    // either be aligned to a 32-bit boundary, or can be misaligned from a 32-bit boundary by
    // exactly one 16-bit half-word.
    if ((uintptr_t)pData & 0x2)
    {
        if (HAL_OK != HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, address, *(const uint16_t*)(pData)))
        {
            return false;
        }
        
        address += 2;
        pData = (const void*)((uintptr_t)pData + 2);
        --dataSize16BitValues;
    }
    
    // Process 64-bit chunks.
    while (dataSize16BitValues >= 4)
    {
        if (HAL_OK != HAL_FLASH_Program(FLASH_TYPEPROGRAM_DOUBLEWORD, address, *(const uint64_t*)(pData)))
        {
            return false;
        }
        
        address += 8;
        pData = (const void*)((uintptr_t)pData + 8);
        dataSize16BitValues -= 4;
    }
    
    // Process any remaining 16-bit half-words.
    if (dataSize16BitValues >= 2)
    {
        if (HAL_OK != HAL_FLASH_Program(FLASH_TYPEPROGRAM_WORD, address, *(const uint32_t*)(pData)))
        {
            return false;
        }
        
        address += 4;
        pData = (const void*)((uintptr_t)pData + 4);
        dataSize16BitValues -= 2;
    }

    if (dataSize16BitValues)
    {
        if (HAL_OK != HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, address, *(const uint16_t*)(pData)))
        {
            return false;
        }
    }
    
    return true;
}
